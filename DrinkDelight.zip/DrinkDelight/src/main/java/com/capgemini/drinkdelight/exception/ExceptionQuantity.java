package com.capgemini.drinkdelight.exception;
public class ExceptionQuantity extends Exception
{
	@Override
	public String toString() 
	{
		return "Enter a Valid Quantity";
	}
}

package com.capgemini.drinkdelight.exception;

public class ExceptionStatus extends Exception
{
	@Override
	public String toString() 
	{
		return "Enter a valid status";
	}
}

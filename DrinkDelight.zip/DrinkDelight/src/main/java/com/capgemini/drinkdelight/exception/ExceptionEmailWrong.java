package com.capgemini.drinkdelight.exception;
public class ExceptionEmailWrong extends Exception
{
	@Override
	public String toString() 
	{
		return "Email has been inputed wrong";
	}
}
